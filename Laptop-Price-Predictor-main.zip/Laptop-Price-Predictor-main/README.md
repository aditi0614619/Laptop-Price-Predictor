https://laptop-price-predictor-8yfhns8vzj6ght4zfmgyzi.streamlit.app/
